let DiaryEntry = require('./diary_entries').DiaryEntry
let AbstractEntriesStore = require('./diary_entries').AbstarctEntriesStore
let moment = require('moment')

const mongoose = require('mongoose')
const connectDB = async () => {
    try {
        await mongoose.connect(process.env.DB_URL, {
            useNewUrlParser: true,
            useUnifiedTopology: true
        })
    }catch (err) {
        console.log(err)
    }
}

exports.MongooseEntriesStore = class MongooseEntriesStore extends AbstractEntriesStore {

    async update(key, date, title, notes) {

        await connectDB()
        let entry = await DiaryEntry.findOneAndUpdate({key: key}, {
            date: date,
            title: title,
            notes: notes
        })
        await mongoose.disconnect()
        return entry
    }

    async create(key, date, title, notes) {

        await connectDB()

        let entry = new DiaryEntry({
            key: key,
            date: date,
            title: title,
            notes: notes
        })
        entry = await entry.save()
        await mongoose.disconnect()
        return entry
    }

    async read(key) {

        await connectDB()
        const entry = await DiaryEntry.findOne({ key: key})
        await mongoose.disconnect()
        return entry
    }

    async destroy(key) {

        await connectDB()
        await DiaryEntry.findOneAndDelete({key: key})
        await mongoose.disconnect()
    }

    async findAllDairyEntries() {

        await connectDB()
        const entries = await DiaryEntry.find({})
        await mongoose.disconnect()

        return entries.map(entry => {
            return {
                key: entry.key,
                date: moment.utc(entry.date).format("YYYY MMM D (dddd)"),
                title: entry.title
            }
        })
    }

    async count() {
       return Date.now() + Math.random()
    }

}